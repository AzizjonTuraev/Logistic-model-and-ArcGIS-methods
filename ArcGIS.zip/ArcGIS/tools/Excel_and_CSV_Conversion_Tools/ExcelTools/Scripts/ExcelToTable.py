# -*- coding: utf-8 -*-
"""
This script will convert an excel file to an ArcGIS table as specified by the
  user
"""
# import required modules
import arcpy
import os
import sys
import datetime
import domainvalues
try:
    import xlrd
except:
    arcpy.AddError("Import of XLRD module failed.\nThe XLRD module can be \
    downloaded from: http://pypi.python.org/pypi/xlrd")

def sheet_names(in_excel):
    """ Returns a list of sheet names for the selected excel file """
    # open the excel file
    wb = xlrd.open_workbook(in_excel)
    potential_sheets = [sht.name for sht in wb.sheets()]
    return potential_sheets

def open_excel_table(in_excel, sheet_name):
    wb = xlrd.open_workbook(in_excel)
    if sheet_name.upper() != "FIRST":
        try:
            ws = wb.sheet_by_name(sheet_name)

            return ws, wb
        except:
            arcpy.AddError('Invalid Sheet Name')
            sys.exit()
    else:
        ws = wb.sheet_by_index(0)
        return ws, wb


def in_data(in_excel, out_table, sheet_name):
    """ Returns a list of field types and field values from the input file """

    # Open excel file and begin reading data

    # Find the output file type
    typeFileSystem = False
    if arcpy.Describe(os.path.dirname(out_table)).workspaceType == 'FileSystem':
        typeFileSystem = True

    # open the excel file
    sht, wb = open_excel_table(in_excel, sheet_name)

    # set up a dictionary of the known file types in xlrd
    DataTypesDict = {0: None, 1: 'Text', 2: 'Double',
    3: 'Date', 4: 'Short', 5: 'Error', 6: None}

    values = []
    # get the first row of the excel file to use as the fieldnames
    HeaderVals = sht.row_values(0)

    # get 2 lists for row types, the same length as the fieldnames. The second
    # list is updated for every row to check if the types match.
    dataTypes = [None for x in range(0, len(HeaderVals))]
    dataTypes2 = dataTypes[:]
    # get all rows after the first one (was already read as the field names)
    for i in range(1, sht.nrows):
        row = sht.row_values(i)
        # loop through each cell in the current row
        for x in range(0, sht.ncols):
            # get the current data types for each column
            dataTypes2[x] = DataTypesDict[sht.cell_type(i, x)]

            # 1. if the current type is null:
            if dataTypes2[x] == None:
                # dbf and info tables cannot deal with null values, so they
                # must be changed to different values that retain the
                # knowledge of a null value
                if typeFileSystem:
                    if dataTypes[x] == "Text":
                        row[x] = ""
                    elif dataTypes[x] == 'Date':
                        row[x] = 0
                    else:
                        row[x] = -999999
                else:
                    row[x] = None

            # 2. If the cell type is a date, then convert it from a numeric
            # to a datetime value
            elif dataTypes2[x] == 'Date':
                datetime.datetime
                row[x] = datetime.datetime(*xlrd.xldate_as_tuple(row[x],
                                            wb.datemode))

            # 3. if the field type has been set, and the types dont match,
            # raise an error
            if dataTypes2[x] and dataTypes[x] != None and dataTypes2[x] != dataTypes[x]:
                dataTypes[x] = 'Text'

            # 4. if the current cell type is null, dont try to update the
            # actual cell type for that column
            elif dataTypes2[x] == None and dataTypes[x] != None:
                pass
            # 5. if the row type has not yet been set, set it to the current
            # cell type value
            else:
                dataTypes[x] = dataTypes2[x]
        values.append(row)

    # if any of the fieldtypes are null after reading all data, change them
    # to 'long' to allow the creation of that field without failure.
    for x in range(0, len(dataTypes)):
        if dataTypes[x] == None:
            dataTypes[x] = 'Long'
    return dataTypes, values


def validate_fields(in_excel, out_table, sheet_name):
    """ validates field names, eliminating duplicate names and invalid
      characters """

    sht = open_excel_table(in_excel, sheet_name)[0]
    fieldnames = sht.row_values(0)

    initialList = domainvalues.validate(out_table, fieldnames)
    return initialList

def make_table(out_table, fieldnames, fieldTypes):
    """ create the output table, add all required fields for that table """
    # create a table as specified by the user

    arcpy.CreateTable_management(os.path.dirname(out_table),
                                 os.path.basename(out_table))

    # add the fields that were validates using the previous function.
    for i in range(0, len(fieldnames)):
        arcpy.AddField_management(out_table, fieldnames[i], fieldTypes[i])
    # Delete any of the fields created by default, other than the OID field
    for f in arcpy.ListFields(out_table):
        if f.type != 'OID' and f.name.lower() not in fieldnames:
            arcpy.DeleteField_management(out_table, f.name)
    return


def excel_to_table(in_excel, out_table):
    """ execute all required functions, and insert values into table """
    # call the function to get lists of data, fields, and fieldtypes
    arcpy.AddMessage('Reading Excel file...')
    types, vals = in_data(in_excel, out_table, sheet_name)
    # call the function to validate fields
    initialList = validate_fields(in_excel, out_table, sheet_name)
    # call the function to create the table
    arcpy.AddMessage("Creating Table")
    make_table(out_table, initialList, types)

    # insert all the values into the newly created table
    arcpy.AddMessage("Inserting Rows")

    # if running on 10.1, use da insert cursor
    if arcpy.GetInstallInfo()['Version'] == '10.1':
        insertCur = arcpy.da.InsertCursor(out_table, initialList)
        for row in vals:
            insertCur.insertRow(row)


    # otherwise use original insert cursor
    else:
        insertCur = arcpy.InsertCursor(out_table)
        for val in vals:
            row = insertCur.newRow()
            for x in range(len(val)):
                row.setValue(initialList[x], val[x])
            insertCur.insertRow(row)
    del row, insertCur

if __name__ == "__main__":
    # allow overwrite of tables
    arcpy.env.overwriteOutput = True

    # Get the parameters of the tool
    in_excel = arcpy.GetParameterAsText(0)
    sheet_name = arcpy.GetParameterAsText(1)
    out_table = arcpy.GetParameterAsText(2)

    # run it
    try:
        excel_to_table(in_excel, out_table)
    except Exception as err:
        arcpy.AddError("Error: {0}".format(err))

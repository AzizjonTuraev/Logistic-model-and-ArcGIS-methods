# -*- coding: utf-8 -*-
"""
This script is referenced by a tool that will convert a CSV file to an
  ArcGIS table specified by the user
"""
import arcpy
import csv
import os
import sys
import codecs
import domainvalues


def in_data(in_csv, dialect, out_table):
    """ Returns a list of field types and field values from the input file """

    # Find the output file system before entering loop
    typeFileSystem = False
    if arcpy.Describe(os.path.dirname(out_table)).workspaceType == 'FileSystem':
        typeFileSystem = True

    arcpy.AddMessage("Reading CSV file")
    # open csv file to begin reading data

    csv_to_read = csv.reader(open(in_csv, 'r'), dialect=dialect)

    values = []
    i = 0
    for row in csv_to_read:
        p = row[:]
        # for all values not to be used as fieldnames
        if i != 0:
            # determine the value types for each row
            for x in range(0, len(fieldnames)):
                # If the value is null, set it to a null value that ArcGIS will
                # understand
                if row[x] == "" or row[x] == " " or row[x] == "None":
                    if typeFileSystem:
                        if fieldTypes[x] != "Text":
                            row[x] = -99999
                        else:
                            row[x] = ""
                    else:
                        row[x] = None
                else:
                    # if the fieldtype has already been set, confirm that it
                    # does not vary from that field type. If it does, fall
                    # back to text
                    if fieldTypes[x] == "Double":
                        try:
                            float(row[x])
                        except:
                            fieldTypes[x] = "Text"
                    elif fieldTypes[x] == "Long":
                        try:
                            int(row[x])
                        except:
                            try:
                                float(row[x])
                                fieldTypes[x] = 'Double'
                            except:
                                fieldTypes[x] = "Text"

                    elif fieldTypes[x] == "Text":
                        pass

                    # if the fieldtype has not yet been set, set it to either
                    # double, text, or long
                    else:
                        if row[x].find('.') != -1:
                            try:
                                float(row[x])
                                fieldTypes[x] = "Double"
                            except:
                                fieldTypes[x] = "Text"
                        else:
                            try:
                                float(row[x])
                                fieldTypes[x] = "Long"
                            except:
                                fieldTypes[x] = "Text"

            # append values of this row to the rest
            values.append(tuple(row))

        # get values for the fieldnames, and fill the field types list with the
        # correct number of values
        else:
            # get rid of any BOM on the first row
            row = [unicode(r, errors='ignore') for r in row]
            # get fieldnames, in utf-8
            fieldnames = map(domainvalues._encodeHeader, row)

            fieldTypes = [None for x in range(0, len(fieldnames))]

        i += 1
    del row, csv_to_read

    # If a field has all null values, a field type would not have been set. if
    # this is the case, set the field as a long
    for x in range(0, len(fieldTypes)):
        if not fieldTypes[x]:
            fieldTypes[x] = "Long"
    return fieldTypes, values


# the validate_fields function contains some overlap with the in_data function
# (opening the csv file, reading the first row), but is necessary to allow
# easier validation within the script tool parameters
def validate_fields(in_csv, out_table, dialect):
    """ validates field names, eliminating duplicate names and invalid
      characters """
    # open csv file to begin reading data
    csv_to_read = csv.reader(open(in_csv, 'rb'), dialect=dialect)
    row = csv_to_read.next()
    row = [unicode(r, errors='ignore') for r in row]
    fieldnames = map(domainvalues._encodeHeader, row)
    initialList = domainvalues.validate(out_table, fieldnames)

    return initialList


def make_table(out_table, fieldnames, fieldTypes):
    """ create the output table, add all required fields for that table """
    # create a table as specified by the user
    arcpy.AddMessage("Creating Table")
    arcpy.CreateTable_management(os.path.dirname(out_table), os.path.basename(
    out_table))

    # Add all the fields to the table
    fieldlist = []
    for i in range(0, len(fieldnames)):
        arcpy.AddField_management(out_table, fieldnames[i], fieldTypes[i])

    # Delete any of the fields created by default, other than the OID field
    for f in arcpy.ListFields(out_table):
        if not f.required and f.name.lower() not in fieldnames:
            arcpy.DeleteField_management(out_table, f.name)
    return


def table_to_csv(in_csv, out_table):
    """ execute all required functions, and insert values into table """
    # call the function to get lists of data and fieldtypes
    types, vals = in_data(in_csv, dialect, out_table)

    # call the function to get and validate the fieldnames
    initialList = validate_fields(in_csv, out_table, dialect)

    # call the function to create the table
    make_table(out_table, initialList, types)

    # insert all the values into the newly created table
    arcpy.AddMessage("Inserting Rows")

    # if running on 10.1, use da insert cursor
    if arcpy.GetInstallInfo()['Version'] == '10.1':
        insertCur = arcpy.da.InsertCursor(out_table, initialList)
        for row in vals:
            insertCur.insertRow(row)

    # otherwise use original insert cursor
    else:
        insertCur = arcpy.InsertCursor(out_table)
        for val in vals:
            row = insertCur.newRow()
            for x in range(len(val)):
                row.setValue(initialList[x], val[x])
            insertCur.insertRow(row)
    del row, insertCur

if __name__ == "__main__":
    arcpy.env.overwriteOutput = True
    # Get the parameters
    in_csv = arcpy.GetParameterAsText(0)
    out_table = arcpy.GetParameterAsText(1)

    delim = arcpy.GetParameterAsText(2).lower()
    dialect = 'excel'
    if delim == 'comma':
        dialect = 'excel'
    else:
        dialect = 'excel-tab'
    # run it
    try:
        table_to_csv(in_csv, out_table)
    except Exception as err:
        arcpy.AddError("Error: {0}".format(err))
